const KEY="sengolShoppingProducts";
const PLATFORMS=[
["Amazon","https://www.amazon.in/"],["Flipkart","https://www.flipkart.com/"],["Meesho","https://www.meesho.com/"],
["Myntra","https://www.myntra.com/"],["AJIO","https://www.ajio.com/"],["Tata CLiQ","https://www.tatacliq.com/"],["Shopsy","https://www.shopsy.in/"]
];
const SOCIALS=[
["Instagram","https://www.instagram.com/sengol_fashion/"],["Pinterest","https://pin.it/1gLdGoSRR"],
["Facebook","https://www.facebook.com/profile.php?id=61593100736281"],["WhatsApp Channel","https://whatsapp.com/channel/0029VbCpLAEJpe8ds88N1m08"],
["YouTube","https://youtube.com/@sengolgroup"],["X / Twitter","https://x.com/sengolaffiliate"]
];
const $=s=>document.querySelector(s);
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

$("#enter")?.addEventListener("click",()=>$("#welcome").classList.add("hide"));
setTimeout(()=>$("#welcome")?.classList.add("hide"),7000);

$("#menu")?.addEventListener("click",()=>$("#nav").classList.toggle("open"));
$("#nav")?.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>$("#nav").classList.remove("open")));

$("#platforms").innerHTML=PLATFORMS.map(([n,u])=>`<a class="platform" href="${u}" target="_blank" rel="noopener">${esc(n)}<span>Explore →</span></a>`).join("");
$("#socials").innerHTML=SOCIALS.map(([n,u])=>`<a class="social" href="${u}" target="_blank" rel="noopener">${esc(n)} →</a>`).join("");

function getProducts(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return[]}}
function render(){
 const q=($("#search")?.value||"").toLowerCase(),c=$("#filter")?.value||"all";
 const list=getProducts().filter(p=>{const t=((p.name||"")+" "+(p.description||"")).toLowerCase();return(c==="all"||p.category===c)&&(!q||t.includes(q))});
 $("#productsGrid").innerHTML=list.map(p=>{const u=p.affiliateLink||p.directLink||"#";return `<article class="product"><div class="product-img">${p.image?`<img src="${esc(p.image)}" alt="${esc(p.name)}">`:"SENGOL"}</div><p class="cat">${esc(p.category||"Other")}</p><h3>${esc(p.name||"Sengol Product")}</h3><p>${esc(p.description||"Discover this product through Sengol.")}</p>${u!=="#" ? `<a class="btn gold" href="${esc(u)}" target="_blank" rel="noopener nofollow">Shop via Sengol →</a>`:"<button class='btn gold' disabled>Link Coming Soon</button>"}</article>`}).join("");
 $("#empty").style.display=list.length?"none":"block";
}
$("#search")?.addEventListener("input",render);$("#filter")?.addEventListener("change",render);render();

$("#sellForm")?.addEventListener("submit",e=>{e.preventDefault();alert("Thank you! Your product submission has been received for review.");e.target.reset()});

$("#prepare")?.addEventListener("click",()=>{
 const v=$("#affiliateUrl").value.trim();
 if(!v){$("#affiliateResult").textContent="Please paste an authorized affiliate URL.";return}
 try{new URL(v);$("#affiliateResult").innerHTML=`<p>Authorized link prepared:</p><input value="${esc(v)}" readonly><button class="btn gold" id="copy">Copy Link</button>`;$("#copy").onclick=()=>navigator.clipboard?.writeText(v).then(()=>alert("Link copied."))}
 catch{$("#affiliateResult").textContent="Please enter a valid URL."}
});